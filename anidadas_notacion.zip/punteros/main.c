#include <stdio.h>
#include <stdlib.h>

int main()
{
    /*
    int i;
    int vec[5];
    int *ptr;
    int a=15;
    int *b=NULL;
    int* c;

    b=&a;
    printf("&a: %p \t&b: %p \n",&a,&b);
    printf("a: %d\t\tb: %p\n",a,b);
    printf("\t\t*b: %d\n\n",*b);


    a=22;
    printf("Cambio el valor de a=22\n");
    printf("&a: %p \t&b: %p \n",&a,&b);
    printf("a: %d\t\tb: %p\n",a,b);
    printf("\t\t*b: %d\n\n",*b);

    *b=77;
    printf("Cambio el valor del q apunta el puntero *b=77\n");
    printf("&a: %p \t&b: %p \n",&a,&b);
    printf("a: %d\t\tb: %p\n",a,b);
    printf("\t\t*b: %d\n\n",*b);

    ptr=vec;
    for(i=0;i<5;i++)
    {
        *(ptr+i)=(i+3);

    }
    for(i=0;i<5;i++)
    {
            printf("ptr[%d]: %d\n",i,*(ptr+i));
    }
*/



    int H=66;
    int *punteroInt;
    int **punteroPuntero;

    punteroInt = &H; // Obtenemos la posici�n de memoria
    punteroPuntero = &punteroInt; // Obtenemos la posici�n de memoria


    printf("H: %d\t\t*punteroInt:%d\t\t&punteroPuntero:%p\n",H,*punteroInt,&punteroPuntero);
    printf("&H: %p\t&punteroInt:%p\tpunteroPuntero:%p\n",&H,&punteroInt,punteroPuntero);
printf("&H: %p\tpunteroInt:%p\t*punteroPuntero:%p\n",&H,punteroInt,*punteroPuntero);
printf("&H: %p\t*punteroInt:%d\t\t**punteroPuntero:%d\n",&H,*punteroInt,**punteroPuntero);


    return 0;
}
